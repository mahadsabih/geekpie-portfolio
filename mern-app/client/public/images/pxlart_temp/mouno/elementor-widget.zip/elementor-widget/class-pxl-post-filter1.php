<?php

class PxlPostFilter1_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_post_filter1';
    protected $title = 'Case Post Filter';
    protected $icon = 'eicon-taxonomy-filter';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"tab_source","label":"Source","tab":"settings","controls":[{"name":"filter_post_type","label":"Filter Post Type","type":"select","default":"post","options":{"post":"Post","portfolio":"Portfolio","service":"Service"}},{"name":"source_portfolio","label":"Select Term of Portfolio","type":"select2","multiple":true,"options":[],"label_block":true,"condition":{"filter_post_type":["portfolio"]}},{"name":"source_service","label":"Select Term of Service","type":"select2","multiple":true,"options":[],"label_block":true,"condition":{"filter_post_type":["service"]}},{"name":"source_post","label":"Select Term of Post","type":"select2","multiple":true,"options":[],"label_block":true,"condition":{"filter_post_type":["post"]}}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}