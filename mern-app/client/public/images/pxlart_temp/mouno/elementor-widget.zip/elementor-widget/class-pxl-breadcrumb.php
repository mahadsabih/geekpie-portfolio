<?php

class PxlBreadcrumb_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_breadcrumb';
    protected $title = 'Case Breadcrumb';
    protected $icon = 'eicon-yoast';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"section_style_text","label":"Text","tab":"style","controls":[{"name":"text_color","label":"Color","type":"color","selectors":{"{{WRAPPER}} .pxl-breadcrumb a":"color: {{VALUE}};"}},{"name":"text_typography","label":"Typography","type":"typography","control_type":"group","selector":"{{WRAPPER}} .pxl-breadcrumb a, {{WRAPPER}} .pxl-breadcrumb span"}]},{"name":"section_style_icon","label":"Icon","tab":"style","controls":[{"name":"icon_color","label":"Color","type":"color","selectors":{"{{WRAPPER}} .pxl-breadcrumb li + li:before":"color: {{VALUE}};"}},{"name":"icon_size","label":"Size","type":"slider","size_units":["px","%","rem","em","custom"],"control_type":"responsive","selectors":{"{{WRAPPER}} .pxl-links li + li:before":"font-size: {{SIZE}}{{UNIT}};"}}]},{"name":"section_style_active","label":"Active","tab":"style","controls":[{"name":"active_color","label":"Color","type":"color","selectors":{"{{WRAPPER}} .pxl-breadcrumb span":"color: {{VALUE}};"}}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}