<?php

class PxlSlider1_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_slider1';
    protected $title = 'Case Slider 1';
    protected $icon = 'eicon-cart';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"tab_layout","label":"Layout","tab":"layout","controls":[{"name":"layout","label":"Layout","type":"layoutcontrol","default":"1","options":{"1":{"label":"Style 1","image":"http:\/\/mouno.local\/wp-content\/themes\/mouno"},"2":{"label":"Style 2","image":"http:\/\/mouno.local\/wp-content\/themes\/mouno"}}}]},{"name":"tab_slider_content","label":"Slide","tab":"content","controls":[{"name":"slides","label":"Slides","type":"repeater","controls":[{"name":"get_layout","label":"Layout","type":"hidden","default":"traditional"},{"name":"bg_image","label":"Background","type":"media"},{"name":"subtitle","label":"Subtitle","type":"text","label_block":true},{"name":"title","label":"Title","type":"textarea","row":3},{"name":"desc","label":"Description","type":"textarea","row":5}],"title_field":"{{{ title }}}"}]},{"name":"tab_sidebar_content","label":"Sidebar","tab":"content","controls":[{"name":"logo","label":"Logo","type":"media"},{"name":"contact","label":"Contact","type":"text","label_block":true},{"name":"socials","label":"Socials","type":"repeater","controls":[{"name":"social_icon","label":"Icon","type":"icons","fa4compatibility":"icon"}]}]}]}';
    protected $styles = array(  );
    protected $scripts = array( 'swiper','pxl-swiper' );
}