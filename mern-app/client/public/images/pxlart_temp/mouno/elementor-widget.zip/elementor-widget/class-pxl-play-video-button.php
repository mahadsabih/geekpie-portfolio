<?php

class PxlPlayVideoButton_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_play_video_button';
    protected $title = 'Case Play Video Button';
    protected $icon = 'eicon-play';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"tab_btn_content","label":"Play Video Button","tab":"content","controls":[{"name":"btn_style","label":"Button Style","type":"select","default":"pxl-play-video-button1","options":{"pxl-play-video-button1":"Default"}},{"name":"video_link","label":"Video Link","type":"url","default":{"url":"https:\/\/www.youtube.com\/watch?v=NkQlmPCQfgY"}},{"name":"btn_icon","label":"Button Icon","type":"icons","fa4compatibility":"icon","default":{"value":{"url":"https:\/\/demo.casethemes.net\/mouno\/wp-content\/wp-content\/uploads\/2024\/11\/play-video.svg","id":2967},"library":"svg"}}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}