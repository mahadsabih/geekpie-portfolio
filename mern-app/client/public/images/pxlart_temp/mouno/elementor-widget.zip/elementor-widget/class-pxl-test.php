<?php

class PxlTest_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_test';
    protected $title = 'TEST';
    protected $icon = 'eicon-cart';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"tab_layout","label":"Layout","tab":"layout","controls":[{"name":"layout","label":"Layout","type":"layoutcontrol","default":"1","options":{"1":{"label":"Style 1","image":"https:\/\/demo.casethemes.net\/mouno\/wp-content\/themes\/mouno\/elements\/assets\/img\/pxl_accordion\/layout1.jpg"}}}]},{"name":"tab_content","label":"Slider","tab":"content","controls":[{"name":"bg_test","type":"background","control_type":"group","types":["classic","gradient"],"selector":"{{WRAPPER}} .pxl-layout-service .pxl-post-icon","fields_options":{"background":{"label":"Background ABC"},"color":{"selectors":{"{{WRAPPER}} .e-con-overlay":"--pxl-background-color: {{VALUE}};"}}}},{"name":"bg_test_2","type":"background","control_type":"group","types":["classic","gradient"],"selector":"{{WRAPPER}} .pxl-layout-service .pxl-post-icon","fields_options":{"background":{"label":"Background Test @"},"color":{"selectors":{"{{WRAPPER}} .e-con-overlay":"--pxl-background-color: {{VALUE}};"}}}}]}]}';
    protected $styles = array(  );
    protected $scripts = array( 'curtainsjs','mouno-effects','mouno-parallax','tilt' );
}