<?php

class PxlImageBox_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_image_box';
    protected $title = 'BR Image Box';
    protected $icon = 'eicon-image-box';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[]}';
    protected $styles = array(  );
    protected $scripts = array( 'mouno-effects' );
}