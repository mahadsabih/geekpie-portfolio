<?php

class PxlSiteLogo_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_site_logo';
    protected $title = 'Case Site Logo';
    protected $icon = 'eicon-site-logo';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"tab_logo_content","label":"Logo","tab":"content","controls":[{"name":"logo","label":"Site Logo","type":"media","default":{"url":"https:\/\/demo.casethemes.net\/mouno\/wp-content\/uploads\/2024\/11\/logo_demo_light.png"}},{"name":"logo_link","label":"Link","type":"url","default":{"url":"https:\/\/demo.casethemes.net\/mouno\/"}}]},{"name":"tab_logo_style","label":"Site Logo","tab":"style","controls":[{"name":"logo_align","label":"Alignment","type":"choose","control_type":"responsive","options":{"left":{"title":"Left","icon":"fa fa-align-left"},"center":{"title":"Center","icon":"fa fa-align-center"},"right":{"title":"Right","icon":"fa fa-align-right"}},"selectors":{"{{WRAPPER}} .pxl-site-logo-wrapper":"text-align: {{VALUE}};"}},{"name":"logo_color","label":"Color","type":"color","selectors":{"{{WRAPPER}} .pxl-site-logo-wrapper a":"color: {{VALUE}};"}},{"name":"logo_w","label":"Width","type":"slider","size_units":["px","%","custom"],"control_type":"responsive","range":{"px":{"min":0,"max":3000}},"selectors":{"{{WRAPPER}} .pxl-site-logo-wrapper img":"width: {{SIZE}}{{UNIT}};"}},{"name":"logo_max_w","label":"Max Width","type":"slider","size_units":["px","%","custom"],"control_type":"responsive","range":{"px":{"min":0,"max":3000}},"selectors":{"{{WRAPPER}} .pxl-site-logo-wrapper img":"max-width: {{SIZE}}{{UNIT}};"}},{"name":"logo_h","label":"Height","type":"slider","size_units":["px","%","custom"],"control_type":"responsive","range":{"px":{"min":0,"max":3000}},"selectors":{"{{WRAPPER}} .pxl-site-logo-wrapper img":"height: {{SIZE}}{{UNIT}};"}}]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}