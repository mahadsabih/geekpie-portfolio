<?php

class PxlCountdown_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_countdown';
    protected $title = 'Case Countdown';
    protected $icon = 'eicon-countdown';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"countdown_section","label":"Content","tab":"content","controls":[{"name":"date","label":"Date","type":"text","label_block":true,"description":"Set date count down (Date format: yy\/mm\/dd)"}]}]}';
    protected $styles = array(  );
    protected $scripts = array( 'mouno-countdown' );
}